package com.example.smart_house_project

class dataclass_user_login {
}